{ config, pkgs, lib, ... }:

{
  home.stateVersion = "24.11";

  programs.git = {
    enable = true;
    userName = "Tu Nombre";       # cambia esto
    userEmail = "tu@email.com";   # cambia esto
  };

  programs.zsh = {
    enable = true;
    oh-my-zsh = {
      enable = true;
      theme = "robbyrussell";
      plugins = [ "git" "docker" "sudo" ];
    };
    shellAliases = {
      ll = "ls -la";
      update = "sudo nixos-rebuild switch --flake ~/nixos-config#desktop";
      modo = "modo-status";
    };
  };

  # Aqui puedes ir agregando tus dotfiles/configs de Hyprland, waybar, kitty, etc.
  # Ejemplo:
  # home.file.".config/hypr/hyprland.conf".source = ./dotfiles/hyprland.conf;
}

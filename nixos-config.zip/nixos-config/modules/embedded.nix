{ config, pkgs, lib, ... }:

{
  environment.systemPackages = with pkgs; [
    # --- Arduino ---
    arduino-ide
    arduino-cli

    # --- ESP32 (ESP-IDF, esptool) ---
    esptool
    picocom      # monitor serie simple
    minicom

    # --- STM32 ---
    stlink               # st-flash, st-info, st-util
    openocd               # debugging/flashing generico (STM32, ESP32, etc)
    gcc-arm-embedded       # toolchain arm-none-eabi
    stm32cubemx           # IDE grafico de configuracion STM32 (si esta disponible en nixpkgs)

    # --- Herramientas generales de electronica/firmware ---
    platformio            # alternativa multi-plataforma a Arduino IDE (recomendado)
    pulseview              # analizador logico (si usas uno tipo Saleae/DSLogic)
    sigrok-cli
    minicom
    screen                 # monitor serie via `screen /dev/ttyUSB0 115200`

    # --- Python para scripting de automatizacion de hardware ---
    python3Packages.pyserial
    python3Packages.esptool
  ];

  # --- udev rules: permisos para programadores/placas sin sudo ---
  # Cubre ESP32 (CP210x/CH340), STM32 (ST-Link), Arduino (varios chips USB-serial)
  services.udev.extraRules = ''
    # ST-Link V2/V3
    SUBSYSTEM=="usb", ATTRS{idVendor}=="0483", ATTRS{idProduct}=="3748", MODE="0666", GROUP="dialout"
    SUBSYSTEM=="usb", ATTRS{idVendor}=="0483", ATTRS{idProduct}=="374b", MODE="0666", GROUP="dialout"
    SUBSYSTEM=="usb", ATTRS{idVendor}=="0483", ATTRS{idProduct}=="374f", MODE="0666", GROUP="dialout"

    # CH340 (clones Arduino / ESP32 boards comunes)
    SUBSYSTEM=="usb", ATTRS{idVendor}=="1a86", ATTRS{idProduct}=="7523", MODE="0666", GROUP="dialout"

    # CP2102/CP210x (ESP32 devkits, NodeMCU)
    SUBSYSTEM=="usb", ATTRS{idVendor}=="10c4", ATTRS{idProduct}=="ea60", MODE="0666", GROUP="dialout"

    # FTDI (algunos programadores/adaptadores)
    SUBSYSTEM=="usb", ATTRS{idVendor}=="0403", ATTRS{idProduct}=="6001", MODE="0666", GROUP="dialout"
  '';

  # El usuario ya esta en "dialout" via common.nix, necesario para /dev/ttyUSB*
}

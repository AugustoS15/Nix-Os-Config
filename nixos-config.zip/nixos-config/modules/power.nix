{ config, pkgs, lib, ... }:

let
  # --- Script: modo silencio ---
  # Prioriza bateria y silencio de ventiladores. GPU NVIDIA queda apagada (offload only).
  modoSilencio = pkgs.writeShellScriptBin "modo-silencio" ''
    echo ">> Activando modo SILENCIO (bateria/silencio)"
    sudo ${pkgs.linuxPackages_latest.cpupower}/bin/cpupower frequency-set -g powersave
    sudo ${pkgs.tlp}/bin/tlp bat
    if [ -f /sys/firmware/acpi/platform_profile ]; then
      echo "low-power" | sudo tee /sys/firmware/acpi/platform_profile
    fi
    echo "Listo. CPU en powersave, NVIDIA solo por demanda (nvidia-offload)."
  '';

  # --- Script: modo rendimiento ---
  # Balance entre rendimiento y temperatura/bateria. Para dev/estudio diario.
  modoRendimiento = pkgs.writeShellScriptBin "modo-rendimiento" ''
    echo ">> Activando modo RENDIMIENTO (balanceado)"
    sudo ${pkgs.linuxPackages_latest.cpupower}/bin/cpupower frequency-set -g schedutil
    sudo ${pkgs.tlp}/bin/tlp ac
    if [ -f /sys/firmware/acpi/platform_profile ]; then
      echo "balanced" | sudo tee /sys/firmware/acpi/platform_profile
    fi
    echo "Listo. CPU en schedutil (balanceado), TLP en modo AC."
  '';

  # --- Script: modo turbo ---
  # Maximo rendimiento para gaming/compilaciones pesadas. Mas ruido/consumo/calor.
  modoTurbo = pkgs.writeShellScriptBin "modo-turbo" ''
    echo ">> Activando modo TURBO (maximo rendimiento)"
    sudo ${pkgs.linuxPackages_latest.cpupower}/bin/cpupower frequency-set -g performance
    sudo ${pkgs.tlp}/bin/tlp ac
    if [ -f /sys/firmware/acpi/platform_profile ]; then
      echo "performance" | sudo tee /sys/firmware/acpi/platform_profile
    fi
    # Fuerza a la NVIDIA a maximo rendimiento (PowerMizer nivel 3) si hay sesion grafica activa
    if [ -n "$DISPLAY" ] || [ -n "$WAYLAND_DISPLAY" ]; then
      ${pkgs.linuxPackages_latest.nvidia_x11.settings}/bin/nvidia-settings -a "[gpu:0]/GpuPowerMizerMode=1" 2>/dev/null || true
    fi
    echo "Listo. CPU en performance, GPU forzada a maximo rendimiento."
  '';

  # --- Script informativo: ver modo actual ---
  modoStatus = pkgs.writeShellScriptBin "modo-status" ''
    echo "=== Estado actual de energia ==="
    echo "Governor CPU:"
    cat /sys/devices/system/cpu/cpu0/cpufreq/scaling_governor
    if [ -f /sys/firmware/acpi/platform_profile ]; then
      echo "Platform profile: $(cat /sys/firmware/acpi/platform_profile)"
    fi
    echo "TLP:"
    sudo ${pkgs.tlp}/bin/tlp-stat -s
  '';
in
{
  # cpupower para controlar el governor de la CPU manualmente
  powerManagement.cpuFreqGovernor = lib.mkForce "schedutil"; # default al bootear = rendimiento balanceado

  environment.systemPackages = [
    modoSilencio
    modoRendimiento
    modoTurbo
    modoStatus
    pkgs.powertop
  ];

  # Permite usar cpupower/tlp/nvidia-settings sin pedir password cada vez (opcional pero comodo)
  security.sudo.extraRules = [
    {
      users = [ "tuusuario" ];
      commands = [
        { command = "${pkgs.linuxPackages_latest.cpupower}/bin/cpupower"; options = [ "NOPASSWD" ]; }
        { command = "${pkgs.tlp}/bin/tlp"; options = [ "NOPASSWD" ]; }
        { command = "${pkgs.tlp}/bin/tlp-stat"; options = [ "NOPASSWD" ]; }
        { command = "/run/current-system/sw/bin/tee /sys/firmware/acpi/platform_profile"; options = [ "NOPASSWD" ]; }
      ];
    }
  ];
}

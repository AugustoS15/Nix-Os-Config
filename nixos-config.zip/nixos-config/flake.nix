{
  description = "Configuracion NixOS personal - portable entre pendrive y disco";

  inputs = {
    nixpkgs.url = "github:NixOS/nixpkgs/nixos-unstable";

    home-manager = {
      url = "github:nix-community/home-manager";
      inputs.nixpkgs.follows = "nixpkgs";
    };

    hyprland.url = "github:hyprwm/Hyprland";

    # Repo de NixOS con muchos paquetes/tools extra de seguridad
    nixpkgs-security.url = "github:Mic92/nixpkgs-security-tools";
  };

  outputs = { self, nixpkgs, home-manager, hyprland, ... }@inputs:
    let
      system = "x86_64-linux";
      pkgs = import nixpkgs {
        inherit system;
        config.allowUnfree = true; # necesario para drivers NVIDIA
      };
    in {
      nixosConfigurations = {
        # Host para el pendrive de 128GB (instalacion de pruebas real)
        pendrive = nixpkgs.lib.nixosSystem {
          inherit system;
          specialArgs = { inherit inputs; };
          modules = [
            ./hosts/pendrive/configuration.nix
            ./modules/common.nix
            ./modules/hyprland.nix
            ./modules/nvidia-laptop.nix
            ./modules/dev.nix
            ./modules/security.nix
            ./modules/embedded.nix
            ./modules/gaming.nix
            ./modules/power.nix
            home-manager.nixosModules.home-manager
            {
              home-manager.useGlobalPkgs = true;
              home-manager.useUserPackages = true;
              home-manager.users.tuusuario = import ./home/home.nix;
            }
          ];
        };

        # Host para el dual boot final en el disco Toshiba 1TB
        desktop = nixpkgs.lib.nixosSystem {
          inherit system;
          specialArgs = { inherit inputs; };
          modules = [
            ./hosts/desktop/configuration.nix
            ./modules/common.nix
            ./modules/hyprland.nix
            ./modules/nvidia-laptop.nix
            ./modules/dev.nix
            ./modules/security.nix
            ./modules/embedded.nix
            ./modules/gaming.nix
            ./modules/power.nix
            home-manager.nixosModules.home-manager
            {
              home-manager.useGlobalPkgs = true;
              home-manager.useUserPackages = true;
              home-manager.users.tuusuario = import ./home/home.nix;
            }
          ];
        };
      };
    };
}

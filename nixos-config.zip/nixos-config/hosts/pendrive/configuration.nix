{ config, pkgs, lib, ... }:

{
  imports = [
    ./hardware-configuration.nix  # Genera este con nixos-generate-config cuando instales en el pendrive
  ];

  networking.hostName = "pendrive";
}

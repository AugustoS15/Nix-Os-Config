{ config, pkgs, lib, ... }:

{
  imports = [
    ./hardware-configuration.nix  # Este archivo lo genera nixos-generate-config, REEMPLAZA el que dejamos aqui
  ];

  networking.hostName = "desktop"; # cambia el nombre si quieres otro

  # Bootloader ya definido en modules/common.nix (systemd-boot)
  # pero confirmamos que use el disco correcto:
  boot.loader.efi.efiSysMountPoint = "/boot";
}

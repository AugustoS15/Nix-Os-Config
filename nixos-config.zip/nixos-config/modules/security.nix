{ config, pkgs, lib, ... }:

{
  # Herramientas estandar de analisis de seguridad / pentesting
  # (uso etico, en tus propios sistemas o con autorizacion)
  environment.systemPackages = with pkgs; [
    burpsuite
    metasploit
    john          # john the ripper
    hashcat
    aircrack-ng
    nikto
    sqlmap
    hydra
    gobuster
    ffuf
    netcat-gnu
    tcpdump
    binwalk
    radare2
    ghidra
    volatility3   # analisis forense de memoria
    yara
    exploitdb
    tor
    proxychains-ng
  ];

  # GPU passthrough util para hashcat con NVIDIA (cracking acelerado por GPU)
  hardware.graphics.enable = true; # ya esta en nvidia-laptop.nix, redundante pero explicito

  # Requerido para captura de paquetes sin sudo
  programs.wireshark.enable = true;
  users.users.tuusuario.extraGroups = [ "wireshark" ];

  # AppArmor para hardening adicional del sistema
  security.apparmor.enable = true;

  # Auditoria del sistema
  security.auditd.enable = true;
  security.audit.enable = true;
}

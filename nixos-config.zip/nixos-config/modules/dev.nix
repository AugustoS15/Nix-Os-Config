{ config, pkgs, lib, ... }:

{
  # Docker/Podman para contenedores
  virtualisation.docker.enable = true;
  virtualisation.docker.rootless = {
    enable = true;
    setSocketVariable = true;
  };

  environment.systemPackages = with pkgs; [
    # Editores / IDEs
    vscode
    neovim

    # Lenguajes y toolchains generales
    python3
    python3Packages.pip
    nodejs_22
    rustup
    go
    gcc
    gnumake
    cmake

    # Herramientas de dev
    docker-compose
    lazygit
    lazydocker
    postman
    jq
    yq

    # Version control extra
    gh # github cli

    # Utilidades de red para debugging
    nmap
    wireshark
    dig
  ];

  # Wireshark sin sudo
  programs.wireshark.enable = true;

  # direnv: mucho mas comodo trabajar por-proyecto con nix-shell/flakes
  programs.direnv = {
    enable = true;
    nix-direnv.enable = true;
  };
}

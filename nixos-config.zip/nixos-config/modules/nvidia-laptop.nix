{ config, pkgs, lib, ... }:

{
  # Graficos hibridos: AMD (integrada) + NVIDIA RTX 3050 (dedicada)
  # Necesario para que Hyprland/Wayland funcionen bien en laptop Optimus

  # IMPORTANTE: debes correr `lspci | grep -E "VGA|3D"` en tu laptop
  # para confirmar los Bus IDs correctos de AMD y NVIDIA y reemplazarlos abajo.
  # Ejemplo tipico: AMD = "0000:65:00.0", NVIDIA = "0000:01:00.0"

  hardware.graphics = {
    enable = true;
    enable32Bit = true; # necesario para gaming/Steam/Proton
  };

  services.xserver.videoDrivers = [ "nvidia" ];

  hardware.nvidia = {
    modesetting.enable = true;
    powerManagement.enable = true;
    powerManagement.finegrained = true; # apaga la NVIDIA cuando no se usa, ahorra bateria
    open = false; # driver propietario (mas estable que el open-source por ahora)
    nvidiaSettings = true;
    package = config.boot.kernelPackages.nvidiaPackages.stable;

    prime = {
      offload = {
        enable = true;
        enableOffloadCmd = true; # te da el comando `nvidia-offload`
      };
      # AJUSTA estos Bus IDs con el resultado real de lspci en tu laptop:
      amdgpuBusId = "PCI:65:0:0";
      nvidiaBusId = "PCI:1:0:0";
    };
  };

  # Driver AMD (integrada, la que corre por defecto)
  hardware.cpu.amd.updateMicrocode = true;

  # Kernel reciente ayuda mucho con hardware laptop nuevo (Ryzen 6000 series)
  boot.kernelPackages = pkgs.linuxPackages_latest;

  # Parametros utiles para laptops con graficos hibridos
  boot.kernelParams = [ "nvidia-drm.modeset=1" ];

  # TLP para mejor manejo de energia en laptop (mejor que power-profiles-daemon con NVIDIA)
  services.tlp.enable = true;
  services.power-profiles-daemon.enable = false; # conflictua con TLP
}

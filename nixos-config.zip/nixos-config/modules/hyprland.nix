{ config, pkgs, lib, ... }:

{
  programs.hyprland = {
    enable = true;
    xwayland.enable = true; # necesario para apps que no soportan Wayland nativo
  };

  # Portal para compartir pantalla, capturas, etc en Wayland
  xdg.portal = {
    enable = true;
    extraPortals = [ pkgs.xdg-desktop-portal-hyprland ];
    config.common.default = "*";
  };

  # Login manager
  services.displayManager.sddm = {
    enable = true;
    wayland.enable = true;
  };

  services.displayManager.defaultSession = "hyprland";

  # Variables de entorno recomendadas para NVIDIA + Wayland + Hyprland
  environment.sessionVariables = {
    NIXOS_OZONE_WL = "1"; # apps Electron/Chromium usan Wayland nativo
    LIBVA_DRIVER_NAME = "nvidia";
    GBM_BACKEND = "nvidia-drm";
    __GLX_VENDOR_LIBRARY_NAME = "nvidia";
    WLR_NO_HARDWARE_CURSORS = "1"; # evita bug de cursor invisible en NVIDIA
  };

  # Herramientas del ecosistema Hyprland para personalizacion completa
  environment.systemPackages = with pkgs; [
    waybar          # barra superior
    wofi            # launcher de apps
    swaynotificationcenter  # notificaciones
    swaylock-effects       # bloqueo de pantalla
    swayidle        # gestion de suspension/idle
    hyprpaper       # wallpapers
    hyprlock        # lock screen nativo de hypr
    hypridle
    grim slurp      # capturas de pantalla
    wl-clipboard    # portapapeles
    polkit_gnome    # prompts de permisos graficos
    kitty           # terminal (rapida, va bien con Hyprland)
    nautilus        # explorador de archivos (o usa 'yazi' si prefieres TUI)
    pavucontrol     # control de volumen grafico
    networkmanagerapplet
    brightnessctl
    playerctl
  ];

  fonts.packages = with pkgs; [
    nerd-fonts.jetbrains-mono
    nerd-fonts.fira-code
    noto-fonts
    noto-fonts-emoji
  ];

  # GTK/Qt themes coherentes (para que apps no-nativas de Hypr se vean bien)
  qt.enable = true;
  qt.platformTheme = "gtk2";
}

{ config, pkgs, lib, ... }:

{
  programs.steam = {
    enable = true;
    remotePlay.openFirewall = true;
    dedicatedServer.openFirewall = false;
    gamescopeSession.enable = true; # util para juegos que se benefician de gamescope
  };

  programs.gamemode.enable = true; # optimiza CPU/GPU automaticamente al jugar

  environment.systemPackages = with pkgs; [
    lutris
    heroic          # launcher para Epic Games/GOG
    mangohud        # overlay de FPS/temps
    protonup-qt     # gestor de versiones de Proton-GE
    winetricks
    wineWowPackages.stable
    gamescope
  ];

  # Necesario para que Steam/Proton usen la GPU dedicada correctamente
  hardware.graphics.enable32Bit = true;
}

{ config, pkgs, lib, ... }:

{
  # --- Bootloader ---
  # systemd-boot funciona bien para dual boot UEFI
  boot.loader.systemd-boot.enable = true;
  boot.loader.efi.canTouchEfiVariables = true;
  # Timeout para poder elegir entre NixOS y el otro OS en dual boot
  boot.loader.timeout = 5;

  # --- Localizacion ---
  time.timeZone = "America/Lima"; # cambia esto a tu zona horaria real
  i18n.defaultLocale = "es_PE.UTF-8"; # ajusta a tu locale (es_MX.UTF-8, es_ES.UTF-8, etc)

  console.keyMap = "la-latin1"; # teclado latinoamericano, cambia si usas otro

  # --- Red ---
  networking.networkmanager.enable = true;

  # --- Nix settings ---
  nix.settings.experimental-features = [ "nix-command" "flakes" ];
  nix.settings.auto-optimise-store = true;

  # Limpieza automatica de generaciones viejas (importante en pendrive, espacio limitado)
  nix.gc = {
    automatic = true;
    dates = "weekly";
    options = "--delete-older-than 14d";
  };

  # --- Usuario ---
  users.users.tuusuario = {
    isNormalUser = true;
    description = "Tu Usuario";
    extraGroups = [ "wheel" "networkmanager" "video" "audio" "dialout" "docker" ];
    shell = pkgs.zsh;
  };
  programs.zsh.enable = true;

  # --- Sonido moderno (pipewire) ---
  security.rtkit.enable = true;
  services.pipewire = {
    enable = true;
    alsa.enable = true;
    alsa.support32Bit = true;
    pulse.enable = true;
  };

  # --- Firewall basico habilitado por defecto (lo relajamos en security.nix si hace falta) ---
  networking.firewall.enable = true;

  # --- Paquetes base del sistema ---
  environment.systemPackages = with pkgs; [
    git
    curl
    wget
    vim
    neovim
    htop
    btop
    tree
    unzip
    ripgrep
    fd
    fzf
    tmux
    gnupg
    file
    usbutils
    pciutils
  ];

  # --- SSD/Pendrive: trim automatico (importante para vida util del pendrive) ---
  services.fstrim.enable = true;

  system.stateVersion = "24.11";
}
